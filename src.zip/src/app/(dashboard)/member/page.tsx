// Page dashboard membre
import AuthGuard from '@/lib/auth/auth-guard';
import MemberDashboard from '@/components/dashboard/MemberDashboard';     

export default function MemberPage() {
  return (
    <AuthGuard roles={['member', 'admin']} requireAuth={true}>
      <MemberDashboard />
    </AuthGuard>
  );
}